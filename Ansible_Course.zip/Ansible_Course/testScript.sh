#! /bin/bash
pwd >> /tmp/ansible_folder/fileCratedByScript.txt
echo "first arg: $1" >> /tmp/ansible_folder/fileCratedByScript.txt
echo "===========================================================" >> /tmp/ansible_folder/fileCratedByScript.txt

ifconfig >> /tmp/ansible_folder/fileCratedByScript.txt
